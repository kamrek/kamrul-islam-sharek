<!DOCTYPE HTML>
<html lang="en-US">
	<head>
		<meta charset="UTF-8">
		<title>RMSTU Online Judge</title>
  
	<link rel="stylesheet" href="themes/default/default.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="themes/light/light.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="themes/dark/dark.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="themes/bar/bar.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="css/nivo-slider.css" type="text/css" media="screen" />		


		<link rel="stylesheet" href="style.css" />
		
	<link rel="icon" href="img/favicon.png" type="image/png" />
	<link rel="shortcut icon" href="img/favicon.ico" />		

		
	</head>
	<body>
	<div class="main_wrap header_bg">
		<div class="wrap">
			<header>
				<div id="header">
					<h2>Welcome to RMSTU Online Judge</h2>
					<p><marquee>This is the first Online Judge for RMSTU students.</marquee></p>
				</div>
				
			</header>			
		</div>
	</div>	
	<div class="main_wrap nav_bg">
		<div class="wrap">
			<nav>
				<div id="nav">
					<ul>
						<li><a href="#">Home</a></li>
						<li><a href="Contest.php">Contest</a></li>
						<li><a href="archieve.php">Problem Archive</a></li>
						<!-- <li><a href="#">Menu Item &raquo;</a>
							<ul>
								<li><a href="#">Dropdown Item</a></li>
								<li><a href="#">Dropdown Item</a></li>
								<li><a href="#">Dropdown Item  &raquo;</a>
									<ul>
										<li><a href="#">Sub Dropdown Item</a></li>
										<li><a href="#">Sub Dropdown Item</a></li>
										<li><a href="#">Sub Dropdown Item</a></li>
										<li><a href="#">Sub Dropdown Item</a></li>
										<li><a href="#">Sub Dropdown Item</a></li>
									</ul>							
								</li> 
								<li><a href="#">Dropdown Item</a></li>
								<li><a href="#">Dropdown Item</a></li>
							</ul>  -->
						</li>
						<li><a href="OnlineCompiler.php">Compiler</a></li>
						<li><a href="Ranks.php">Ranks</a></li>
						<li><a href="Logout.php">Logout</a></li>
						<li><a href="UpdateUser.php"><?php include("SessionEdit.php");?></a></li>
					</ul>
				</div>
			</nav>			
		</div>
	</div>
	<div class="main_wrap slider_bg">
		<div class="wrap">
			<section>
				<div id="slider_wrapper">

					<div class="slider-wrapper theme-dark">
						<div id="slider" class="nivoSlider">
						    
							<img src="img/2.jpg" />
							<img src="img/3.jpg" />
							<img src="img/4.jpg" />
							<img src="img/5.jpg" />
							<img src="img/6.png" />
							<img src="img/7.jpg" />
							
						</div> 
					</div>
				</div>					
		</section>			
		</div>
	</div>
	<div class="main_wrap content_bg">
	       <h1></h1>
		<div class="wrap">
			<div id="content_wrapper">
				<div id="content">
					<article id="main_article_single">
						<h2>Course Coordinator:</h2><h3>Mithun Dutta</h3>
						<div id="imgp_wrap">
							<img src="img/Sir.jpg" alt="" />
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendreri [...]</p>
						</div>
					</article>
					<article id="main_article_single">
						<h2>Utpol Kanti Das.</h2>
						<div id="imgp_wrap">
							<img src="img/Utpol.jpg" alt="" />
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendreri [...]</p>
						</div>
					</article>
					<article id="main_article_single">
						<h2>M. Kamrul Islam Sharek</h2>
						<div id="imgp_wrap">
							<img src="img/Sharek.jpg" alt="" />
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendreri [...]</p>
						</div>
					</article>
					<article id="main_article_single">
						<h2>Shadat Hossain Hridoy</h2>
						<div id="imgp_wrap">
							<img src="img/Hridoy.jpg" alt="" />
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendreri [...]</p>
						</div>
					</article>					
				</div>
				<div id="sidebar">
					<aside id="main_sidebar">
						<h2>Sidebar Heading:</h2>
						<ul>
							<li><a href="#">List Item</a></li>
							<li><a href="#">List Item</a></li>
							<li><a href="#">List Item</a></li>
							<li><a href="#">List Item</a></li>
							<li><a href="#">List Item</a></li>
						</ul>
					</aside>
					<aside id="main_sidebar">
						<h2>Sidebar Heading:</h2>
						<ul>
							<li><a href="#">List Item</a></li>
							<li><a href="#">List Item</a></li>
							<li><a href="#">List Item</a></li>
							<li><a href="#">List Item</a></li>
							<li><a href="#">List Item</a></li>
						</ul>
					</aside>
					<aside id="main_sidebar">
						<h2>Sidebar Heading:</h2>
						<ul>
							<li><a href="#">List Item</a></li>
							<li><a href="#">List Item</a></li>
							<li><a href="#">List Item</a></li>
							<li><a href="#">List Item</a></li>
							<li><a href="#">List Item</a></li>
						</ul>
					</aside>					
				</div>
			</div>			
		</div>
	</div>
	<div class="main_wrap footer_bg">
		<div class="wrap">
			<footer>
				<div id="footer">
				<p>Developed by</p>
					<p>Utpol Kanti Das,Kamrul Islam Sharek,Shadat hossain Hridoy&copy; 2019 RMSTU</p>
				</div>
			</footer>			
		</div>
	</div>
			
<!--

	<div class="main_wrap">
		<div class="wrap">
			
		</div>
	</div>

-->			

    <script type="text/javascript" src="js/jquery-1.9.0.min.js"></script>
    <script type="text/javascript" src="js/jquery.nivo.slider.js"></script>
	
    <script type="text/javascript">
    $(window).load(function() {
        $('#slider').nivoSlider();
    });
    </script>	
	
	</body>
</html>