
<!DOCTYPE html>
<html>
<head>
</head>
<body>
<center>

</div>
<br>
<h1>All Submission</h3><br>
</center>
<center>
    <table class="table">
    <thead>
    <tr>
	 <th>Serial No.</th>
	 <th>User Name </th>
     <th>Problem Id </th>
     <th>Problem Name  </th>
     <th>Result  </th>
     <th> CPU TIME</th>
    </tr>
    </thead>
    <tbody>
<?php
 $i=1;
	 $link=mysqli_connect("localhost","root","") or die("We couldn't connect !");
	mysqli_select_db($link,"RMSTUOJ");
	
 $query=mysqli_query($link,"SELECT * from Submissions ORDER BY Id DESC");
while($row=mysqli_fetch_array($query))
{
     echo "<tr>
	 <td>$i</td>
      <td><a href=\"profile.php?user=$row[uname]\">$row[uname]</a></td>
	 <td><a href=\"showcode.php?Pid=$row[Pid]&uname=$row[uname]\">$row[Pid]</a>
	 <td><a href=\"description.php?Pname=$row[Pname]\">$row[Pname]</a></td>
	 <td><div class=\"\">$row[Result]&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div></td>
	 <td>$row[CPU]</td></tr>";
    $i++;
}

  echo "</tbody>
</table>
</div>";
?>

</center>
</body>
</html>
