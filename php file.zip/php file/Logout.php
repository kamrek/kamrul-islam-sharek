<?php
session_start();

$expire = time() - 86400;
setcookie('My',$_SESSION['uname'],$expire);
session_destroy();
echo "Session Destroyed!";
header("Refresh:3; url=Login.php");

?>