
<?php
session_start();

if(!isset($_SESSION['uname'])){
	echo "Access Denied!";
	header("Refresh:3, Location:login.php");
}
else{
	putenv("PATH=C:\Program Files (x86)\CodeBlocks\MinGW\bin");
if($_POST['code'])
{
$lang=$_POST['language'];
$source=$_POST['code'];
//$input=$_POST['in'];
$Pname=$_POST['Pname'];
$Pid=$_POST['Pid'];
$uname=$_SESSION['uname'];
$Type=$_POST['Ptype'];

$link=mysqli_connect("localhost","root","") or die("We couldn't connect !");
mysqli_select_db($link,"RMSTUOJ");
if($Type=='Easy'){
	$query=mysqli_query($link,"SELECT * from easyarchieve where Pid=$Pid");
}else if($Type=='Beginner'){
	$query=mysqli_query($link,"SELECT * from beginnerarchieve where Pid=$Pid");
}
else if($Type=='Medium'){
	$query=mysqli_query($link,"SELECT * from mediumarchieve where Pid=$Pid");
}
else if($Type=='Hard'){
	$query=mysqli_query($link,"SELECT * from hardarchieve where Pid=$Pid");
}
$row=mysqli_fetch_array($query);
$limit=$row['Timelim'];

//$input=$r4['tc'];
     putenv("PATH=C:\Program Files (x86)\CodeBlocks\MinGW\bin");
    $CC="gcc";
	$out="timeout 5s ./a.out";
	$code=$_POST["code"];
	$input=$row['Input'];
	$filename_code="main.c";
	$filename_in="input.txt";
	$filename_error="error.txt";
	$executable="a.out";
	$command=$CC." -lm ".$filename_code;	
	$command_error=$command." 2>".$filename_error;
	$check=0;
	$tle=0;
	$ce=0;

	//if(trim($code)=="")
	//die("The code area is empty");
	
	$file_code=fopen($filename_code,"w+");
	fwrite($file_code,$code);
	fclose($file_code);
	$file_in=fopen($filename_in,"w+");
	fwrite($file_in,$input);
	fclose($file_in);
	exec("chmod 777 $executable"); 
	exec("chmod 777 $filename_error");	

	shell_exec($command_error);
	$error=file_get_contents($filename_error);

    $executionStartTime = microtime(true);
	if(trim($error)=="")
	{
		if(trim($input)=="")
		{
			$output=shell_exec($out);
		}
		else
		{
			$out=$out." < ".$filename_in;
			$output=shell_exec($out);
		}


		
		//echo "<pre>$output</pre>";
        //echo "<textarea id='div' class=\"form-control\" name=\"output\" rows=\"10\" cols=\"50\">$output</textarea><br><br>";
		        // echo "<div class=\"row\"><div class=\"col-sm-4\">
				// </div><div class=\"col-sm-6\"><div class=\"alert alert-success\">
				// <strong>Successfully Compiled!</strong> Click Below Submit Button To Submit.</div>
				// </div><div class=\"col-sm-2\"></div></div><br>";
	}
	else if(!strpos($error,"error"))
	{
		echo "<pre>$error</pre>";
		if(trim($input)=="")
		{
			$output=shell_exec($out);
		}
		else
		{
			$out=$out." < ".$filename_in;
			$output=shell_exec($out);
		}



		//echo "<pre>$output</pre>";
                //echo "<textarea id='div' class=\"form-control\" name=\"output\" rows=\"10\" cols=\"50\">$output</textarea><br><br>";
				// echo "<div class=\"row\"><div class=\"col-sm-4\"></div><div class=\"col-sm-6\"><div class=\"alert alert-success\"><strong>Successfully Compiled!</strong> Click Below Submit Button To Submit.</div></div><div class=\"col-sm-2\"></div></div><br>";
	}
	else
	{
		echo "<pre>$error</pre>";
		$check=1;
		$ce=1;
			echo "<div class=\"row\"><div class=\"col-sm-4\"></div>
			<div class=\"col-sm-6\"><div class=\"alert alert-danger\">
			<strong>Compilation Error Or Submit Failed!</strong> Back To Problem Description And Submit Code Again.</div></div><div class=\"col-sm-2\"></div></div><br>";
	}
	$executionEndTime = microtime(true);
	$seconds = $executionEndTime - $executionStartTime;
	$seconds = sprintf('%0.2f', $seconds);
	//echo "<pre>Compiled And Executed In: $seconds s</pre>";
    
    

	if($seconds>$limit)
	{
		$fr="lt";
	}
	else if($ce==1)
	{
		 $fr="e";
	}
	else if(trim($output)=="")
	{
          $fr="rte";
	}

	exec("rm $filename_code");
	exec("rm *.o");
	exec("rm *.txt");
	exec("rm $executable");

	if($check==0 || $check==1)
	{
		$link=mysqli_connect("localhost","root","") or die("We couldn't connect !");
		mysqli_select_db($link,"RMSTUOJ");
		if($Type=='Easy'){
			$query=mysqli_query($link,"INSERT into easyCodes VALUES(NULL,'$uname','$Pid','$Pname','$Code')");
		}else if($Type=='Beginner'){
			$query=mysqli_query($link,"INSERT into beginneCodes VALUES(NULL,'$uname','$Pid','$Pname','$Code')");
		}
		else if($Type=='Medium'){
			$query=mysqli_query($link,"INSERT into MediumCodes VALUES(NULL,'$uname','$Pid','$Pname','$Code')");
		}
		else if($Type=='Hard'){
			$query=mysqli_query($link,"INSERT into HardCodes VALUES(NULL,'$uname','$Pid','$Pname','$Code')");
		}
		
        //$nsql="INSERT into codes VALUES(NULL,'$Pid','$Pname','$uname','$source')";
		//$usql="UPDATE archieve SET uoutput='$output' WHERE id='$pid'";
		//$csql="SELECT uoutput FROM archieve WHERE id='$pid'";
		$q3="SELECT Id FROM easyCodes ORDER BY Id DESC ";
		//$sql=mysqli_query($link,$nsql);
		//$snd=mysqli_query($con,$usql);
		//$cnd=mysqli_query($con,$csql);
		$sq3=mysqli_query($con,$q3);
		//$r2=mysqli_fetch_array($cnd);
		$r4=mysqli_fetch_array($sq3);




		$uo=$output;
		$ac=$row['output'];
		$nid=$r4['Id'];

		//var_dump($uo);
		//echo "<br><br>";
		//var_dump($ac);


		//echo "$uo<br>";

	}
	//echo "<div class=\"row\"><div class=\"col-sm-5\"></div><div class=\"col-sm-5\"><form action=\"allsubmission.php\" method=\"POST\"><input type=\"hidden\" name=\"pb\" value=\"$pb\"><input type=\"hidden\" name=\"id\" value=\"$pid\"><input type=\"hidden\" name=\"mid\" value=\"$nid\"><input type=\"hidden\" name=\"vd\" value=\"$fr\"><input type=\"hidden\" name=\"il\" value=\"$tle\"><textarea style=\"display:none\" name=\"result\" rows=\"10\" cols=\"10\">$output</textarea><input class=\"btn btn-success tm\" type=\"submit\" value=\"Submit Code\"> </div><div class=\"col-sm-2\"></div></div>";

  }
}
?>
<?php
session_start();

if(!isset($_SESSION['uname'])){
	echo "Access Denied!";
}
else{
	include("session.php");
	include("heading.php");	
}
?>
<?php

error_reporting(0);
if(isset($_POST['Pid']))
{
 
}
    $link=mysqli_connect("localhost","root","") or die("We couldn't connect !");
	mysqli_select_db($link,"RMSTUOJ");
	$query="SELECT output FROM easyarchieve WHERE Pid='$Pid'";
    $sq=mysqli_query($link,$query);
    $r3=mysqli_fetch_array($sq);

$ao=$r3['output'];

  if($result!="lt")
  {
   
    if($result=="e")
    {
      $result="Compilation Error";
    }
    else if(strcmp($uo,$ao)==0)
    {
      $result="Accepted";
    }
    else if($result=="rte")
    {
      $result="Runtime Error";
      
    }
    else
    {
      $result="Wrong Answer";
    }
  }
  else
  {
     $result="Time Limit Exceed";
  }
  $uname=$_SESSION['uname'];
  $Pid=$_POST['Pids'];
  $Pname=$_POST['Pnames'];
  $cpu=$seconds;
  $Type=$_POST['Ptypes'];
	echo $uname ;
	echo $Pid;
	echo $Pname;
	echo $result;
	echo $cpu;
	//$sql="INSERT INTO submissions VALUES(null,'$uname','$Pid','$Pname','$result','$cpu') ";

   //$show="SELECT * FROM submissions ORDER BY Id DESC limit $start,$per_page";

   $stq=mysqli_query($link,$sql);
   $sts=mysqli_query($link,$show);
	echo "<table>";
	while($row=mysqli_fetch_array($sts))
{

 echo "<tr>
	 </td><td><a href=\"profile.php?user=$row[uname]\">$row[uname]</a></td>
	 <td><a href=\"showcode.php?Pid=$row[Pid]&uname=$row[uname]\">$row[Pid]</a>
	 <td><a href=\"description.php?Pname=$row[Pname]\">$row[Pname]</a></td>
	 <td><div class=\"\">$row[Result]</div></td>
	 <td>$row[CPU]</td></tr>";

}
	
	echo "</table>";
	
?>
