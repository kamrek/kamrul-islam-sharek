
<!DOCTYPE html>

<html>
    <head>
           <title>Insert Problem</title>
		   <link rel="stylesheet" href="css/login.css"  type ="text/css">
	        <meta charset="utf-8">
    </head>
		<body>
			   <div id="wrapper">
			   <div id="navbar">
					 <ul>
			           <li><a href="#">Compiler</a></li>
			           <li><a href="#">Problem Archive </a></li>
			           <li><a href="#">Contests </a></li>
                       <li><a href="#">Debug</a></li>
			           <li><a href="Login.php">LogIn</a></li>
					   <li><a href="#">SignUp</a></li>
					</ul>
			       </div>
				   <center>	
			      <div id="container">
				  <h2 style =""><u>Sign Up</u></h2><br><br>
				  <form enctype="multipart/form-data" method="POST" action="problemInsert.php">
				  <label for ="Ptype">Problem Type</label><br>
				  <input type="text" name="Ptype" placeholder="Problem Type(Easy,Beginner,Medium,Hard)"><br>
				  <label for ="Pid">Problem Id</label><br>
				  <input type="text" name="Pid" placeholder="Enter Problem Id(Pid-001)"><br>
				  <label for ="Pname">Problem Name</label><br>
				  <input type="text" name="Pname" placeholder="Enter Problem Name"><br>
				  <label for ="description">Problem Description</label><br>
				  <textarea name="Pdes" id="" cols="30" rows="10"></textarea><br>
				  <label for ="Image">Choose your Problem Image</label><br>
				 <input type="file" name="fileToUpload" id="fileToUpload"><br/><br/>

				  <input id="btn" type="submit" value="Submit" name="submit"> &nbsp;&nbsp;
				  <button type="reset" class="reset"><b>Reset</b></button>
                   </form>   
</div>
</center>
					<div id="footer">
					Developed By:
					Utpol Kanti Das,Kamrul Islam Sharek, ShadatHossain  Hridoy &copy; 2019 RMSTU.
					</div>
		    
			</div>
       </body>
</html>