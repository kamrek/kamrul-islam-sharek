
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="css/ContestSubmission.css"  type ="text/css">
</head>
<body>

<center>

</div>
<br>
<h1>All Submission</h3><br>
</center>
<center>
    <table class="table" border="1">
    <thead>
    <tr>
	 <th>Serial No.&nbsp;&nbsp;&nbsp;&nbsp;</th>
	 <th>User Name&nbsp;&nbsp; </th>
     <th>Problem Id &nbsp;&nbsp;</th>
     <th>Problem Name &nbsp;&nbsp; </th>
     <th>Result  </th>&nbsp;&nbsp;
     <th> CPU TIME</th>&nbsp;&nbsp;
	 <th>Language<th>
    </tr>
    </thead>
    <tbody>
<?php
 $i=1;
	 $link=mysqli_connect("localhost","root","") or die("We couldn't connect !");
	mysqli_select_db($link,"RMSTUOJ");
	
 $query=mysqli_query($link,"SELECT * from contestSubmissions where Cid='$cid' ORDER BY Id DESC");
while($row=mysqli_fetch_array($query))
{
     echo "<tr>
	 <td>$i</td>
      <td><a href=\"profile.php?user=$row[uname]\">$row[uname]</a></td>
	 <td><a href=\"showcode.php?Pid=$row[Pid]&uname=$row[uname]\">$row[Pid]</a>
	 <td><a href=\"description.php?Pname=$row[Pname]\">$row[Pname]</a></td>
	 <td><div class=\"\">$row[Result]&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div></td>
	 <td>$row[CPU]</td>
	 <td>$row[Language]</td>
	 </tr>";
    $i++;
}

  echo "</tbody>
</table>
</div>";
?>

</center>
<div id="footera">

<b>Developed by</b><br>
<b>Utpol Kanti Das,Kamrul Islam Sharek, Shadat Hossain  Hridoy &copy; 2019 RMSTU. </b>

</div>
</body>
</html>
