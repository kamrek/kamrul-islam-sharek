<?php
session_start();

if(!isset($_SESSION['uname'])){
	echo "Access Denied!";
}
else{
	$uname=$_SESSION['uname'];
    include("session.php");
	include("heading.php");	
echo "<h3>Choose an Id to Update :</h3>";
global $link;
$link=mysqli_connect("localhost","root","") or die("We couldn't connect !");
mysqli_select_db($link,"RMSTUOJ");

$query=mysqli_query($link,"SELECT * from users where uname='$uname'");

echo "<table width=\"90%\" align=center border=2>";
echo "<tr>
<td width=\"40%\" align=center bgcolor=\"FFFF00\">ID</td>
<td width=\"40%\" align=center bgcolor=\"FFFF00\">Name</td>
<td width=\"40%\" align=center bgcolor=\"FFFF00\">User Name</td>
<td width=\"40%\" align=center bgcolor=\"FFFF00\">Email</td>
<td width=\"40%\" align=center bgcolor=\"FFFF00\">Password</td>
</tr>";
while($row = mysqli_fetch_assoc($query)){
	$Id=$row['Id']; 
	$name=$row['name']; 
	$uname=$row['uname']; 
	$email=$row['email']; 
	$password=$row['password']; 
	
	echo "<tr>
	    <td align=center>
		<a href=\"edit.php?Ids=$Id&names=$name&unames=$uname&emails=$email&passwords=$password\">$Id</a>
		</td>
		<td align=center>
		 $name
		</td>
		<td align=center>
		 $uname
		</td>
		<td align=center>
		 <a href=\"emailto.php?emails=$email\">$email</a>
		</td>
		<td align=center>
		 $password
		</td>
	</tr>";
}
echo "</table>";

	mysqli_close($link);
}
?>