#include<iostream>
using namespace std;
int main(){
    int A,B,sum;
    cin>>A>>B;
    sum= A+B;
  cout<<"SOMA = "<<sum<<endl;
}