<?php

$target_dir = "images/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

$name = $_POST['name'];
$uname = $_POST['uname'];
$email = $_POST['email'];
$password = $_POST['password'];
$Confirmpassword = $_POST['Confirmpassword'];
global $link;
$link=mysqli_connect("localhost","root","") or die("We couldn't connect !");
mysqli_select_db($link,"RMSTUOJ");
$result=mysqli_query($link,"SELECT *  from users");
$row = mysqli_fetch_array($result);
if($name){
	if($uname && $row['uname'] != $uname){
		if(preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/",$email)){
			if($password){
				if(strlen($password)>3){
					if($Confirmpassword){
						if($password==$Confirmpassword){
							$link=mysqli_connect("localhost","root","") or die("We couldn't connect !");
							mysqli_select_db($link,"RMSTUOJ");
							
							// Check if image file is a actual image or fake image
							if(isset($_POST["submit"])) {
								$check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
								if($check !== false) {
									echo "File is an image - " . $check["mime"] . ".";
									$uploadOk = 1;
								} else {
									echo "File is not an image.";
									$uploadOk = 0;
								}
							}
							// Check if file already exists
							if (file_exists($target_file)) {
								echo "Sorry, file already exists.";
								$uploadOk = 0;
							}
							// Check file size
							if ($_FILES["fileToUpload"]["size"] >1000000) {
								echo "Sorry, your file is too large.";
								$uploadOk = 0;
							}
							// Allow certain file formats
							if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
							&& $imageFileType != "gif" ) {
								echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
								$uploadOk = 0;
							}
							// Check if $uploadOk is set to 0 by an error
							if ($uploadOk == 0) {
								echo "Sorry, your file was not uploaded.";
							// if everything is ok, try to upload file
							} else {
								$directory = "./profiles/$uname/images/";
								mkdir($directory, 0777, true);
								if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], "profiles/$uname/$target_file")) {

								echo "This will be your profile picture!<p><br/><img border='1' width='50' height='50' src='profiles/$uname/$target_file' alt='Profile Picture' />";
						   
						    $passwordmd5 = md5($password);
							mysqli_query($link,"INSERT INTO users(name,uname,email,password) VALUES('$name','$uname','$email','$passwordmd5')");
							
							// $registered = mysqli_affected_rows($link);
   
							echo "You are Successfully registered.<br/><a href='Login.php'>Log In Now</a>";
							
								} else {
									echo "Sorry, there was an error uploading your file.";
									
								}
							}
                            
							}						
							else{
								echo "You have to input same password.";
								}
							}
							else{
								echo "You have to Confirm password.";
						}
					}
					else{
					 echo "Your password too short.You have enter password between 4 and 10 character.";
				 }
            }
			else{
					 echo "You have to enter a password.";
				 }
        }
		else{
			    echo "You have to enter a valid email.";
			 }
    }
	else{
			echo "User name already exist.Please enter another name.";
		}
    }
     else{
	      echo "You have to input your name.";
    }
	mysqli_close($link);
?>