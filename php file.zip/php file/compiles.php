<?php

	$languageID=$_POST["language"];
	
		switch($languageID)
			{
				case "c":
				{
					include("C:/xampp/htdocs/RMSTUOnlineJudge/c.php");
					break;
				}
				case "python":
				{
					include("C:/xampp/htdocs/RMSTUOnlineJudge/compilers/python.php");
					break;
				}
				case "ruby":
				{
					include("C:/xampp/htdocs/RMSTUOnlineJudge/compilers/ruby.php");
					break;
				}

				case "cpp":
				{
					include("C:/xampp/htdocs/RMSTUOnlineJudge/compilers/cpp.php");
					break;
				}
				case "java":
				{	
					include("C:/xampp/htdocs/RMSTUOnlineJudge/compilers/java.php");
					break;
				}
			
			}
?>
