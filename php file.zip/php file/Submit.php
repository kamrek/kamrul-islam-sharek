<?php
session_start();

if(!isset($_SESSION['uname'])){
	echo "Access Denied!";
	header("Location:Login.php");
}
else{
	include("session.php");
	include("heading.php");	
}
?>

<?php

$c=0;

if(isset($_POST['Pid']) && isset($_POST['Ptype']))
{
   $problemid=$_POST['Pid'];
   $Type=$_POST['Ptype'];
   $Pname=$_POST['Pname'];
  echo "<br />Problem Id : $problemid </br> Problem Name: $Pname";
   $c=1;  

$link=mysqli_connect("localhost","root","") or die("We couldn't connect !");
mysqli_select_db($link,"RMSTUOJ");
if($Type=='Easy'){
	$query=mysqli_query($link,"SELECT * from easyarchieve where Pid='$problemid'");
}else if($Type=='Beginner'){
	$query=mysqli_query($link,"SELECT * from beginnerarchieve");
}
else if($Type=='Medium'){
	$query=mysqli_query($link,"SELECT * from mediumarchieve");
}
else if($Type=='Hard'){
	$query=mysqli_query($link,"SELECT * from hardarchieve");
}
$row=mysqli_fetch_array($query);
}

//echo "<textarea  style=\"display:none;\" name=\"in\" 

?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
 
   <center>
   <br />
	<form enctype="multipart/form-data" action="compiles.php" method="POST">
	<label for="language">Choose Language : </label>

	<select name="language" id="language">
	<option value="c">C</option>
	<option value="cpp">C++</option>
	<option value="java">Java</option>
	</select><br><br>
	
	
	<br />
	<label for="code">Write Your Code</label>	<br />
	<textarea name="code" rows="20" cols="50"></textarea><br><br>
	<input type="hidden" name="uname" value="<?php $_SESSION['uname']; ?>">
	<input type="hidden" name="Pids" value="<?php echo $row['Pid']; ?>">
	<input type="hidden" name="Pnames" value="<?php echo $row['Pname']; ?>">
	<input type="hidden" name="input" value="<?php echo $row['Input']; ?>">
	<input type="hidden" name="Ptypes" value="<?php echo $Type; ?>"/>
	<input type="hidden" name="output" value="<?php echo $row['Output']; ?>"/>
	<input type="submit" name="submit" value="Submit"><br><br><br>
</form>
    </center>
</body>
</html>