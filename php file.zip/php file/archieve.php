
<?php
session_start();

if(!isset($_SESSION['uname'])){
	echo "Access Denied!";
	header("Location:login.php");
}
else{
	include("session.php");
	include("heading.php");
    }
?>
	<!DOCTYPE HTML>
	<html lang="en-US">
	<head>
		<meta charset="UTF-8">
		<title>
		</title>
		<link rel="stylesheet" href="css/catagories1.css"  type ="text/css">

	</head>
	<body>
			<div id="Top-container">
				<div id="Top-container-left">
					<h3>RMSTU OJ</h3>
					<h3>Problem & Contest</h3>
					</div>
						<div id="Top-container-right">
						<h2>CATEGORIES</h2>
						 </div>
				</div>
	   <form action="problems.php" method="POST">

	   <br /><br />
	   <div id="right-panel">
	         <div id="right-panel-container-right">
					<button type="submit" name="type" value="Beginner"/>
						<h2>1.BEGINER</h2>
							 <p>Basic program for anyone who are started to programming<br>
								100 PROBLEMS</li></p>				 
					</button>
					
					<button type="submit" name="type" value="Medium"/>
						<h2>3.Medium</h2>
							 <p>Medium problems solvable using simple mathematical formulas and simple algorithms<br>
								100 PROBLEMS</li></p>	 
				</button>
			</div>
			<div id="right-panel-container-right">
				<button type="submit" name="type" value="Easy"/>
						<h2>2.Easy</h2>
							 <p>Easy problems are those problems solvable by a beginner level coder.
							 <br>
								100 PROBLEMS</li></p>
							 	 
				</button>
					<button type="submit" name="type" value="Hard"/>
						<h2>4.Hard</h2>
							 <p>Hard problems are solvable using all data structure theory and algorithms.<br>
								200 PROBLEMS</li></p>				
				</button>
		    </div>			 
		</div>
		</form>
	   <div id="footera">

<b>Developed by</b><br>
<b>Utpol Kanti Das,Kamrul Islam Sharek, Shadat Hossain  Hridoy &copy; 2019 RMSTU. </b>

</div>

	</body>
	</html>
