<?php
session_start();

if(!isset($_SESSION['uname'])){
	echo "Access Denied!";
	header("Location:Login.php");
}
else{
	include("session.php");
	include("heading.php");	
}
?>

<?php
	$input1=$_POST["input"];
	$Pid=$_POST['Pids'];
	$Pname=$_POST['Pnames'];
	$Moutput=$_POST['output'];
	$Type=$_POST['Ptypes'];
	$uname=$_SESSION['uname'];
 $link=mysqli_connect("localhost","root","") or die("We couldn't connect !");
mysqli_select_db($link,"RMSTUOJ");
if($Type=='Easy'){
	$query=mysqli_query($link,"SELECT * from easyarchieve where Pid='$Pid'");
}else if($Type=='Beginner'){
	$query=mysqli_query($link,"SELECT * from beginnerarchieve where Pid=$Pid");
}
else if($Type=='Medium'){
	$query=mysqli_query($link,"SELECT * from mediumarchieve where Pid=$Pid");
}
else if($Type=='Hard'){
	$query=mysqli_query($link,"SELECT * from hardarchieve where Pid=$Pid");
}
$row=mysqli_fetch_array($query);
$limit=$row['Timelim'];

$sql1=mysqli_query($link,"SELECT * from Submissions where Pid='$Pid' and Ptype='$Type' and uname='$uname'");
$rw1=mysqli_fetch_array($sql1);
	    if($rw1['Id']!=0){
		   $Submit=$rw1['Submission'];
		}else{
			$Submit=0;
			}
			
		$my_file1 = "OutputMain.txt";
		$handle1 = fopen($my_file1, "w+") or die("Cannot open file:  ".$my_file1);
		fwrite($handle1, $Moutput);
		fclose($handle1);
    putenv("PATH=C:\Program Files (x86)\CodeBlocks\MinGW\bin");
	$CC="gcc";
	$out="a";
	$code=$_POST["code"];
	$input=$_POST["input"];
	$filename_code="main.c";
	$filename_in1="input1.txt";	
	
	$filename_error="error.txt";
	$executable="a";
	$command=$CC." -lm ".$filename_code;	
	$command_error=$command." 2>".$filename_error;
	$check=0;
	$tle=0;
	$ce=0;
	//if(trim($code)=="")
	//die("The code area is empty");
	if (file_exists('OutputRun.txt'))
		 {    
	     $my_file = "OutputRun.txt";
	     $handle = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file);
	 } 
	$output="";
	
	$file_code=fopen($filename_code,"w+");
	fwrite($file_code,$code);
	fclose($file_code);
	$file_in1=fopen($filename_in1,"w+");
	fwrite($file_in1,$input);
	fclose($file_in1);
	$fn = fopen("$filename_in1","r");
      while(! feof($fn)) {
		 $result = fgets($fn);
		$filename_in="input.txt";
		$file_in=fopen($filename_in,"w+");
	   fwrite($file_in,$result);
	    fclose($file_in);
		exec("chmod 777 $executable"); 
		exec("chmod 777 $filename_error");	
	    shell_exec($command_error);
	   $error=file_get_contents($filename_error);
    $executionStartTime = microtime(true);
		 if(trim($error)=="")
		    {
				if(trim($input)=="")
					{
						$output=shell_exec($out);
					}
					else
					{
						$out=$out." < ".$filename_in;
						$output=shell_exec($out);
					}
					//echo "<pre>$output</pre>";
			}
			else if(!strpos($error,"error"))
				{
					//echo "<pre>$error</pre>";
					if(trim($input)=="")
					{
						$output=shell_exec($out);
					}
					else
					{
						$out=$out." < ".$filename_in;
						$output=shell_exec($out);
					}
					//echo "<pre>$output</pre>";
				}
				else
				{
					//echo "<pre>$error</pre>";
					$check=1;
					$ce=1;

				}
					 $my_file = "OutputRun.txt";
				     $handle = fopen($my_file, 'a') or die('Cannot open file:  '.$my_file);
				     fwrite($handle, $output);
                     //fwrite($handle, $output.PHP_EOL);

				exec("rm $filename_code");
				exec("rm *.o");
				exec("rm *.txt");
				exec("rm $executable");

	  }

  fclose($fn);
  fclose($handle);

            	$executionEndTime = microtime(true);
				$seconds = $executionEndTime - $executionStartTime;
				$seconds = sprintf('%0.2f', $seconds);
				//echo "<pre>Compiled And Executed In: $seconds s</pre>";
				$output=file('OutputRun1.txt');
				$my_file2 = "OutputRun.txt";
		        $handle2 = fopen($my_file2, "w+") or die("Cannot open file:  ".$my_file2);
		        fwrite($handle2, $Moutput);
		        fclose($handle2);
				$OutputMains = file('OutputMain.txt');
				$OutputRuns = file('OutputRun.txt');
				$fr="";
				if($seconds>$limit)
				{

					$fr="gt";
				}
				else if($ce==1)
				{
					 $fr="e";
				}
				else if($OutputRuns=="")
				{
					  $fr="rte";
				}
			$Status="Unsolved";
			$Submit=$Submit+1;
			  if($fr!="gt")
				  {
				   
					if($fr=="e")
					{
					  $result="Compilation Error";
					}
					else if($OutputMains==$OutputRuns)
					{
					  //echo "Accepted";
					  $result="Accepted";
					}
					else if($fr=="rte")
					{
					  $result="Runtime Error";
					  
					}
					else
					{
					 //echo "Wrong Answer";
					  $result="Wrong Answer";
					}
				  }
				  else
				  {
					 $result="Time Limit Exceed";
				  }
				  
  					if($check==0 || $check==1)
					{

					if($Type=='Easy'){
						     $sql2=mysqli_query($link,"SELECT * from easyCodes where Pid='$Pid' and uname='$uname'");
							 $rw2=mysqli_fetch_array($sql2);
								 if($rw2['Id']!=0){
									 $Uquery=mysqli_query($link,"UPDATE easyCodes SET Code='$code' where Pid='$Pid' and uname='$uname'");
										 }else{
											  $query=mysqli_query($link,"INSERT into easyCodes VALUES(NULL,'$uname','$Pid','$Pname','$code')");
											 }
						}else if($Type=='Beginner'){
							$sql2=mysqli_query($link,"SELECT * from beginnerCodes where Pid='$Pid' and uname='$uname'");
							 $rw2=mysqli_fetch_array($sql2);
								 if($rw2['Id']!=0){
								 $Uquery=mysqli_query($link,"UPDATE beginnerCodes SET Code='$code' where Pid='$Pid' and uname='$uname'");
								 }else{
									  $query=mysqli_query($link,"INSERT into beginnerCodes VALUES(NULL,'$uname','$Pid','$Pname','$code')");
									 }
						           }
						 else if($Type=='Medium'){
							 $sql2=mysqli_query($link,"SELECT * from MediumCodes where Pid='$Pid' and uname='$uname'");
							 $rw2=mysqli_fetch_array($sql2);
								 if($rw2['Id']!=0){
								 $Uquery=mysqli_query($link,"UPDATE MediumCodes SET Code='$code' where Pid='$Pid' and uname='$uname'");
								 }else{
									$query=mysqli_query($link,"INSERT into MediumCodes VALUES(NULL,'$uname','$Pid','$Pname','$code')");
									 }
					      	}
						else if($Type=='Hard'){
							 $sql2=mysqli_query($link,"SELECT * from HardCodes where Pid='$Pid' and uname='$uname'");
							 $rw2=mysqli_fetch_array($sql2);
								 if($rw2['Id']!=0){
								 $Uquery=mysqli_query($link,"UPDATE HardCodes SET Code='$code' where Pid='$Pid' and uname='$uname'");
								 }else{
									$query=mysqli_query($link,"INSERT into HardCodes VALUES(NULL,'$uname','$Pid','$Pname','$code')");
									 }
						      }
						$Status="Solved";
				     	}

$sql1=mysqli_query($link,"SELECT * from Submissions where Pid='$Pid' and Ptype='$Type' and uname='$uname'");
$rw1=mysqli_fetch_array($sql1);
	    if($rw1['Id']!=0){
			 $Uquery=mysqli_query($link,"UPDATE submissions SET Result='$result',CPU='$seconds',Status='$Status',Submission=$Submit where Pid='$Pid' and Ptype='$Type' and uname='$uname'");
			     }else{
				 $Uquery=mysqli_query($link,"INSERT into submissions VALUES(NULL,'$uname','$Type','$Pid','$Pname','$result','$seconds','$Status',$Submit)");
				}
				
				include("Submission.php");	
?>
