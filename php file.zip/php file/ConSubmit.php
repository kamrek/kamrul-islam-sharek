<?php
session_start();

if(!isset($_SESSION['uname'])){
	echo "Access Denied!";
	header("Location:Login.php");
}
else{
	include("session.php");
	include("heading.php");	
}
?>

<?php

$c=0;

if(isset($_POST['Pid']) && isset($_POST['id']))
{
   $Id=$_POST['id'];
   $Pname=$_POST['Pname'];
   $problemid=$_POST['Pid'];
   
  echo "<br /><b>Problem Id : $problemid </b></br><b> Problem Name: $Pname</b>";
   $c=1;  


}

//echo "<textarea  style=\"display:none;\" name=\"in\" 

?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
	<link rel="stylesheet" href="css/ConSubmit.css"  type ="text/css">
</head>
<body>
  <div id="container">
   <center>
   <br />
	<form enctype="multipart/form-data" action="ContestCompiles.php" method="POST">
	<label for="language">Choose Language : </label>

	<select name="language" id="language">
	<option value="c">C</option>
	<option value="cpp">C++</option>
	</select><br><br>

	<br />
	<label for="code">Write Your Code</label>	<br />
	<textarea name="code" rows="20" cols="50"></textarea><br><br>
	<input type="hidden" name="uname" value="<?php $_SESSION['uname']; ?>">
	<input type="hidden" name="Pids" value="<?php echo $problemid; ?>">
	<input type="hidden" name="Pnames" value="<?php echo $Pname; ?>">
	<input type="hidden" name="ids" value="<?php echo $Id; ?>">
	<input type="submit" name="submit" value="Submit"><br><br><br>
</form>
    </center>
	</div>
	   <div id="footera">

<b>Developed by</b><br>
<b>Utpol Kanti Das,Kamrul Islam Sharek, Shadat Hossain  Hridoy &copy; 2019 RMSTU. </b>

</div>
</body>
</html>