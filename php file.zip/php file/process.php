<?php
session_start();

if($_POST){
	
$_SESSION['uname'] = $_POST['uname'];
$_SESSION['password'] = md5($_POST['password']);
global $link;

if($_SESSION['uname'] && $_SESSION['password']){
	$link=mysqli_connect("localhost","root","") or die("We couldn't connect !");
	mysqli_select_db($link,"RMSTUOJ");
	
	$query=mysqli_query($link,"SELECT *  from users where uname='".$_SESSION['uname']."'");
	$numrows = mysqli_num_rows($query);
	
	if($numrows != 0){
		while($row = mysqli_fetch_assoc($query)){
			$dbuname = $row['uname'];
			$dbpassword = $row['password'];
		}
		if($_SESSION['uname'] == $dbuname){
			if($_SESSION['password'] == $dbpassword){
				
				if(($_POST['remember']) == 'on'){
					$expire =time() + 86400;
					setcookie('RMSTUOnlineJudge',$_POST['uname'],$expire);
				}
				header("location:Home.php");
			}
			else{
				echo "Your password is incorrect!";
			}
		}
		else{
			echo "Your user name is incorrect!";
		}
	}
	else{
		echo "You are not registered!";
	}
}
	else
	{
		echo "You have to type a user name and password.";
	}	
}
else{
	echo "Access Denied!";
}
?>