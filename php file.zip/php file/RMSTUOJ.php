<!DOCTYPE HTML>
<html lang="en-US">
	<head>
		<meta charset="UTF-8">
		<title>RMSTU Online Judge</title>
  
	<link rel="stylesheet" href="themes/default/default.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="themes/light/light.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="themes/dark/dark.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="themes/bar/bar.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="css/nivo-slider.css" type="text/css" media="screen" />		


		<link rel="stylesheet" href="style.css" />
		<link rel="stylesheet" href="css/RMSTUOJ.css" />
		
	<link rel="icon" href="img/favicon.png" type="image/png" />
	<link rel="shortcut icon" href="img/favicon.ico" />		

		
	</head>
	<body>
	<div class="main_wrap header_bg">
		<div class="wrap">
			<header>
				<div id="header">
					<h2>Welcome to RMSTU Online Judge</h2>
					<p><marquee>This is the first Online Judge for RMSTU students.</marquee></p>
				</div>
				
			</header>			
		</div>
	</div>	
	<div class="main_wrap nav_bg">
		<div class="wrap">
			<nav>
				<div id="nav">
					<ul>
						<li><a href="#">Home</a></li>
						<li><a href="Contest.php">Contest</a></li>
						<li><a href="archieve.php">Problem Archive</a></li>
						<!-- <li><a href="#">Menu Item &raquo;</a>
							<ul>
								<li><a href="#">Dropdown Item</a></li>
								<li><a href="#">Dropdown Item</a></li>
								<li><a href="#">Dropdown Item  &raquo;</a>
									<ul>
										<li><a href="#">Sub Dropdown Item</a></li>
										<li><a href="#">Sub Dropdown Item</a></li>
										<li><a href="#">Sub Dropdown Item</a></li>
										<li><a href="#">Sub Dropdown Item</a></li>
										<li><a href="#">Sub Dropdown Item</a></li>
									</ul>							
								</li> 
								<li><a href="#">Dropdown Item</a></li>
								<li><a href="#">Dropdown Item</a></li>
							</ul>  -->
						</li>
						<li><a href="OnlineCompiler.php">Online Compiler</a></li>
						<li><a href="Ranks.php">Ranks</a></li>
						<li><a href="Logout.php">Logout</a></li>
						<li><a href="profile.php"><?php include("SessionEdit.php");?></a></li>
					</ul>
				</div>
			</nav>			
		</div>
	</div>
	<div class="main_wrap slider_bg">
		<div class="wrap">
			<section>
				<div id="slider_wrapper">

					<div class="slider-wrapper theme-dark">
					<video src="videos/newrmstu.mp4"  controls="controls" width="100%" height="400" autoplay="autoplay" muted="muted" loop="loop" >
			
			</video>
					<!--	<div id="slider" class="nivoSlider">
							<img src="img/2.jpg" />
							<img src="img/3.jpg" />
							<img src="img/4.jpg" />
							<img src="img/5.jpg" />
							<img src="img/6.png" />
							<img src="img/7.jpg" />
							
						</div> --->
					</div>
				</div>					
		</section>			
		</div>
	</div>
	<div class="main_wrap content_bg">
	       <h1></h1>
		<div class="wrap">
			<div id="content_wrapper">
				<div id="content">
					<article id="main_article_single">
						<h2>Course Coordinator:</h2><h3>Mithun Dutta</h3>
						<div id="imgp_wrap">
							<img src="img/Sir.jpg" alt="" />
							<p>
							Coding challenge is a competition where a set of coding questions gets 
							released for a period of few hours/days and a list of pre-registered 
							competitors participate by solving these questions and submitting the 
							solutions which gets run against some hidden test cases and competitors 
							are scored based on the test results. A platform hosting such challenges
							is called an online judge. ex: SPOJ, topcoder etc.,uri online judge such
							like an online judge RMSTU OJ .i think it can helpful for the coder and
							competetional student of RMSTU.</p>
						</div>
					</article>
					<article id="main_article_single">
						<h2>Utpol Kanti Das.</h2>
						<div id="imgp_wrap">
							<img src="img/Utpol.jpg" alt="" />
							<p>An online judge is an online system to test programs in  programming 
							contests. They are also used to practice for such contests. Many of these
							systems organize their own contests. The system can compile and execute  
							code, and test them with pre-constructed data. Submitted code may be run
							with restrictions, including time limit, memory limit, security restriction
							and so on. The output of the code will be captured by the system, and
							compared with the standard output. The system will then return the result.
							When mistakes were found in a standard output, rejudgement using the same 
							method must be made.</p>
						</div>
					</article>
					<article id="main_article_single">
						<h2>M. Kamrul Islam Sharek</h2>
						<div id="imgp_wrap">
							<img src="img/Sharek.jpg" alt="" />
							<p>RMSTU OJ was created as a platform to help programmers make it 
							big in the world of algorithms, computer programming and programming 
							contests. At <b>RMSTUOJ</b> we work hard to revive the geek in you by 
							hosting a programming contest at the start of the month and another smaller 
							programming challenge in the middle of the month. We also aim to have
							training sessions and discussions related to algorithms, binary search, 
							technicalities like array size and the likes.</p>
						</p>
						</div>
					</article>
					<article id="main_article_single">
						<h2>Shadat Hossain Hridoy</h2>
						<div id="imgp_wrap">
							<img src="img/Hridoy.jpg" alt="" />
							<p>A Python Programmer and Expert in Operating System<br></b>
							The RMSTU OJ  discusses the types of problems that are frequently occurs
							in programming solution. The exercises have been integrated to this 
							programming  tool so that you can keep track of your progress.</p>
						</p>
						</div>
					</article>					
				</div>
				<div id="sidebar">
					<aside id="main_sidebar">
						<h2>Upcoming Contest </h2>
						<?php
						  $link=mysqli_connect("localhost","root","") or die("We couldn't connect !");
							mysqli_select_db($link,"RMSTUOJ");
							$query=mysqli_query($link,"SELECT * from contest ORDER BY Id DESC");
							$query1=mysqli_query($link,"SELECT MAX(Id) as maxid from contest");
							$row2=mysqli_fetch_array($query1);
							$id=$row2['maxid'];
							while($row=mysqli_fetch_array($query))
							{
								$id2=$row['Id'];
								if($id==$id2)
								{
								echo "<div id='contest1'><a href='contestproblems.php?cname=$row[Cname]&cid=$row[Cid]'><div id='xmm'>Contest Name:
								<p>$row[Cname]</p>
								<br>Contest ID: $row[Cid]<br><br>
								Contest Date: $row[Cdate]<br><br>
								Start Time: $row[Stime]<br>
								<br>End Time:$row[Etime]<br>
								 <br></div></a> </div>";
								 }
							}
						?>
					</aside>
					<aside id="main_sidebar">
						<h2>Programming Language</h2>
						
						<img src="img/logo.gif" alt="" />
						
					</aside>
					<aside id="main_sidebar">
						<h2> Programmer :</h2>
						
						<img src="img/logo2.gif" alt="" height="200px" width="300px" />
						
					</aside>					
				</div>
			</div>			
		</div>
	</div>
	<div class="main_wrap footer_bg">
		<div class="wrap">
			<footer>
				<div id="footer">
				<p>Developed by</p>
					<p>Utpol Kanti Das,Kamrul Islam Sharek,Shadat hossain Hridoy&copy; 2019 RMSTU</p>
				</div>
			</footer>			
		</div>
	</div>
			
<!--

	<div class="main_wrap">
		<div class="wrap">
			
		</div>
	</div>

-->			

    <script type="text/javascript" src="js/jquery-1.9.0.min.js"></script>
    <script type="text/javascript" src="js/jquery.nivo.slider.js"></script>
	
    <script type="text/javascript">
    $(window).load(function() {
        $('#slider').nivoSlider();
    });
    </script>	
	
	</body>
</html>