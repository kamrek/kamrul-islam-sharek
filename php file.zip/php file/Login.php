
<!DOCTYPE html>

<html>
    <head>
	 
           <title>Log In</title>
		   <link rel="stylesheet" href="css/login.css"  type ="text/css">
	        <meta charset="utf-8">
        
    </head>
	 
		<body>
			   <div id="wrapper">
		
					<div id="navbar">
					 <ul>
			           <li><a href="#">Compiler</a></li>
			           <li><a href="#">Problem Archive </a></li>
			           <li><a href="#">Contests </a></li>
                       <li><a href="#">Debug</a></li>
			           <li><a href="#">Logout</a></li>
					   <li><a href="SignUp.php">Sign Up</a></li>
					</ul>
			       </div>

				   <center>	
			      <div id="container">
				  <h2 style =""><u>Log In</u></h2><br><br>
				  <form action="process.php" method="POST">
				  <label for ="text"> User Name</label><br>
				  <input type="text"name="uname" placeholder="Enter username"><br>
				  <label for ="password">Password</label><br>
				  <input type="password"name="password" placeholder="Enter password"><br>
				  <br>
				  <button type="submit" value="submit"><b>Sign In</b></button>&nbsp;&nbsp;
				  <button type="reset" class="reset"><b>Reset</b></button><br>
                   </form>
				      
</div>
</center>

					<div id="footer">
					Developed By:
					Utpol Kanti Das,Kamrul Islam Sharek, Shahadat Hossain Hridoy &copy; 2019 RMSTU.
					</div>

			</div>
       </body>
</html>