<html>
	   <head><title>RMSTU Online Judge</title>
	   <link rel="stylesheet" href="style.css" />
	   <link rel="stylesheet" href="css/RMSTUOJ.css" />
	   </head>
	   <body>
	   <div class="main_wrap header_bg">
		<div class="wrap">
			<header>
				<div id="header">
					<h2>Welcome to RMSTU Online Judge</h2>
					<p><marquee>This is the first Online Judge for RMSTU students.</marquee></p>
				</div>
				
			</header>			
		</div>
	</div>	
	<div class="main_wrap nav_bg">
		<div class="wrap">
			<nav>
				<div id="nav">
					<ul>
						<li><a href="Home.php">Home</a></li>
						<li><a href="Contest.php">Contest</a></li>
						<li><a href="archieve.php">Problem Archive</a></li>
						<li><a href="OnlineCompiler.php">Online Compiler</a></li>
						<li><a href="Ranks.php">Ranks</a></li>
						<li><a href="Logout.php">Logout</a></li>
						<li><a href="profile.php"><?php include("SessionEdit.php");?></a></li>
					</ul>
				</div>
			</nav>			
		</div>
	</div>
	   </body>
	</html>