<?php
session_start();
	   $time = time();
        $date = date('F d,Y, g:i:s a');
        echo "<center>Today is: ".$date."<br/></center>";
if(!isset($_SESSION['uname'])){
	echo "Access Denied!";
}else{
    include("session.php");
	include("heading.php");	
	include("Editform.php");
}
?>
