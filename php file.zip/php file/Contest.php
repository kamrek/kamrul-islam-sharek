<?php
session_start();

if(!isset($_SESSION['uname'])){
	echo "Access Denied!";
	  header("Location:login.php");
}
else{
	include("session.php");
	include("heading.php");	
}
?>

<!DOCTYPE html>
<html>
<head>
  
    
          <meta charset="utf-8">
          <title>Contest</title>
          <link rel="stylesheet" href="css/archive.css"  type ="text/css">

</head>
	   <body>
			   <div id="wrapper1">
			  <center> <br /><h1>All Contest Details</h1><br>
<?php
$link=mysqli_connect("localhost","root","") or die("We couldn't connect !");
mysqli_select_db($link,"RMSTUOJ");
$query=mysqli_query($link,"SELECT * from contest ORDER BY Id DESC");
while($row=mysqli_fetch_array($query))
{
	echo "<div id='contest'><a href='contestproblems.php?cname=$row[Cname]&cid=$row[Cid]'><div id='xmm'>Contest Name:
	<p>$row[Cname]</p>
	<br><br>Contest ID: $row[Cid]<br><br>
	Contest Date: $row[Cdate]<br><br>
	Start Time: $row[Stime]<br>
	<br>End Time:$row[Etime]<br><br>
	 <br><br></div></a> </div>";
}
?>	   
 <br><br><br>
</center>
<div id="footer">

<b>Developed by</b><br>
<b>Utpol Kanti Das,Kamrul Islam Sharek, Shadat Hossain  Hridoy &copy; 2019 RMSTU. </b>

</div>
 </div>

   </body>
</html>