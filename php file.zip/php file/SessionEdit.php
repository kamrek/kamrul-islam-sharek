<?php 
if(!isset($_SESSION['uname']) && isset($_COOKIE['My'])){
	$_SESSION['uname'] = $_COOKIE['RMSTUOnlineJudge'];
}
	$dir="profiles/".$_SESSION['uname']."/images/";
	$open = opendir($dir);
	while(($file = readdir($open)) != FALSE){
		if($file !="."&& $file !=".."&&$file!="Thumbs.db"){
			echo "<img border='1' width='20' height='20' src='$dir/$file' alt='Profile Picture' />";
		}
	}
	echo "&nbsp<b>".$_SESSION['uname']."</b>'s session";
?>