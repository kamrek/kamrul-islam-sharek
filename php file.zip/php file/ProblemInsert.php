<?php

$target_dir = "images/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
$Type = $_POST['Ptype'];
$Id = $_POST['Pid'];
$name = $_POST['Pname'];
$description = $_POST['Pdes'];
global $link;
$link=mysqli_connect("localhost","root","") or die("We couldn't connect !");
mysqli_select_db($link,"RMSTUOJ");

if($Type=='Easy'){
	$query=mysqli_query($link,"SELECT * from easyarchieve");
}else if($Type=='Beginner'){
	$query=mysqli_query($link,"SELECT * from beginnerarchieve");
}
else if($Type=='Medium'){
	$query=mysqli_query($link,"SELECT * from mediumarchieve");
}
else if($Type=='Hard'){
	$query=mysqli_query($link,"SELECT * from hardarchieve");
}
$row = mysqli_fetch_array($query);
if($Type){
		if($Id && $Id!=$row['Pid']){
			if($name){
				$link=mysqli_connect("localhost","root","") or die("We couldn't connect !");
				mysqli_select_db($link,"RMSTUOJ");
							
							// Check if image file is a actual image or fake image
							if(isset($_POST["submit"])) {
								$check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
								if($check !== false) {
									//echo "File is an image - " . $check["mime"] . ".";
									$uploadOk = 1;
								} else {
									echo "File is not an image.";
									$uploadOk = 0;
								}
							}
							// Check if file already exists
							if (file_exists($target_file)) {
								echo "Sorry, file already exists.";
								$uploadOk = 0;
							}
							// Check file size
							if ($_FILES["fileToUpload"]["size"] >1000000) {
								echo "Sorry, your file is too large.";
								$uploadOk = 0;
							}
							// Allow certain file formats
							if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
							&& $imageFileType != "gif" ) {
								echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
								$uploadOk = 0;
							}
							// Check if $uploadOk is set to 0 by an error
							if ($uploadOk == 0) {
								echo "Sorry, your file was not uploaded.";
							// if everything is ok, try to upload file
							} else {
								$directory = "./problems/$Type/$Id/images/";
								mkdir($directory, 0777, true);
								if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], "problems/$Type/$Id/$target_file")) {

								if($Type=='Easy'){
												mysqli_query($link,"INSERT INTO easyarchieve(Pid,Pname,Pdes) VALUES('$Id','$name','$description')");
											}else if($Type=='Beginner'){
												mysqli_query($link,"INSERT INTO beginnerarchieve(Pid,Pname,Pdes) VALUES('$Id','$name','$description')");
											}
											else if($Type=='Medium'){
												mysqli_query($link,"INSERT INTO mediumarchieve(Pid,Pname,Pdes) VALUES('$Id','$name','$description')");
											}
											else if($Type=='Hard'){
												mysqli_query($link,"INSERT INTO hardarchieve(Pid,Pname,Pdes) VALUES('$Id','$name','$description')");
											}
							
							// $registered = mysqli_affected_rows($link);
   
							echo "Problem Successfully stored<br/>";
							header('Refresh:2; url=InsertProblems.php');
							
								} else {
									echo "Sorry, there was an error uploading your file.";
									
								}
							}
                            						
            }
			else{
					 echo "You have to enter Problem Name.";
				 }
        }
		else{
			    echo "Problem Id already exist!";
			 }
	 }
     else{
	      echo "You have to input Problem Type.";
    }
	mysqli_close($link);
?>