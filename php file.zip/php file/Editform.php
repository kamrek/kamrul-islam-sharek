<?php
session_start();

if(!isset($_SESSION['uname'])){
	echo "Access Denied!";
}
else{
	$uname=$_SESSION['uname'];
    include("session.php");
	include("heading.php");	
}
?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>RMSTU OJ</title>
	<link rel="stylesheet" href="css/edituser.css"  type ="text/css">
</head>
<body>
	<div id="wrapper">
  		   <center>	
			      <div id="container">
				  <h2 style =""><u>Edit User: <?php echo $_REQUEST['names'];?></u></h2><br><br>
				  <form enctype="multipart/form-data" method="POST" action="change.php">
				  <label for ="name">Name</label><br>
				  <input type="text" name="newname" value="<?php echo $_REQUEST['names'];?>"/><br>
				  <label for ="text"> User Name</label><br>
				  <input type="text" name="newuname" value="<?php echo $_REQUEST['unames'];?>"/><br>
				  <label for ="email">Email</label><br>
				  <input type="text" name="newemail" value="<?php echo $_REQUEST['emails'];?>"/><br>
				  <label for ="password">Password</label><br>
				  <input type="password" name="newpassword" value=""/><br>
				  <label for ="Image">Choose your Picture</label><br>
				  <input type='file' name='newupload'/><br/><br/>

				 <div  id="btn"><input type="submit" value="Submit" name="submit"> &nbsp;&nbsp; 
				  <input type="reset" value="Reset"/></button></div>
				  <input type="hidden" name="Id" value="<?php echo $_REQUEST['Ids'];?>"/>
                   </form>
	   
</div>
</center>

					<div id="footer">
					<b>Developed By:</b> <br />
					Utpol Kanti Das,Kamrul Islam Sharek, ShadatHossain  Hridoy &copy; 2019 RMSTU.
					</div>
	</form>
</body>
</html>