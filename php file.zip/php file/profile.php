<?php
session_start();

if(!isset($_SESSION['uname'])){
	echo "Access Denied!";
}
else{
	$uname=$_SESSION['uname'];
    include("session.php");
	include("heading.php");	
	
echo "<br /><h3><center>Choose Id to Update</center></h3>";
global $link;
$link=mysqli_connect("localhost","root","") or die("We couldn't connect !");
mysqli_select_db($link,"RMSTUOJ");

$query=mysqli_query($link,"SELECT * from users where uname='$uname'");

while($row = mysqli_fetch_assoc($query)){
	$Id=$row['Id']; 
	$name=$row['name']; 
	$uname=$row['uname']; 
	$email=$row['email']; 
	$password=$row['password']; 

}
	mysqli_close($link);
}
?>

<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>RMSTU OJ</title>
	<link rel="stylesheet" href="css/profile.css"  type ="text/css">
</head>
<body>
	<div id="wrapper">
  		   <center>	
			      <div id="container">
				  <div id="pic">
				  <?php
				  $dir="profiles/".$_SESSION['uname']."/images/";
					$open = opendir($dir);
					while(($file = readdir($open)) != FALSE){
						if($file !="."&& $file !=".."&&$file!="Thumbs.db"){
							echo "<img align='right' border='1' width='100' height='100' src='$dir/$file' alt='Profile Picture' />";
						}
					}
				  ?>
				  </div>
				  <table border="1">
				  <tr>
				  <th>User Id : </th>
				  <td><?php echo "<a href=\"Editform.php?Ids=$Id&names=$name&unames=$uname&emails=$email&passwords=$password\"><b>$Id</b></a>";?></td>
				  </tr>
				  <tr>
				  <th>Name : </th>
				  <td><?php echo $name;?></td>
				  </tr>
				  <tr>
				  <th>User Name : </th>
				  <td><?php echo $uname;?></td>
				  </tr>
				  <tr>
				  <th>Email : </th>
				  <td><?php echo $email;?></td>
				  </tr>
                   </table>   
</div>
</center>

					<div id="footer">
					<b>Developed By: </b><br />
					Utpol Kanti Das,Kamrul Islam Sharek, ShadatHossain  Hridoy &copy; 2019 RMSTU.
					</div>
	</form>
</body>
</html>