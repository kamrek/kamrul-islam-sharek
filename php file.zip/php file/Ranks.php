<?php
session_start();

if(!isset($_SESSION['uname'])){
	echo "Access Denied!";
	header("Location:login.php");
}
else{
	include("session.php");
	include("heading.php");
    }
?>
<html>
<head>
 <link rel="stylesheet" href="css/rank.css"  type ="text/css">
</head>
<body>
<div id="Selection">
<center><br />
    <form enctype="multipart/form-data" action="" method="POST">
        <select name="Type" class="Type">
		    <option value="">--Select--</option>
            <option value="contest">1.Contest</option>
            <option value="Beginner">2.Beginner</option>
            <option value="Easy">3.Easy</option>
			<option value="Medium">4.Medium</option>
			<option value="Hard">5.Hard</option>
        </select> 
        <input type="submit" value="Submit">
    </form><br /><br />
	</center>
	</div>

<?php
if($_POST)
$uname=$_SESSION['uname'];
if($_POST){
$Type=$_POST['Type'];
global $link;
$link=mysqli_connect("localhost","root","") or die("We couldn't connect !");
mysqli_select_db($link,"RMSTUOJ");
echo'<div id="contant">
<table border="1">
     <tr>
	 <th>Rank</th>
	 <th>User Name</th>
	 <th>Solved</th>	 
	 </tr>
       ';
$i=1;
if($Type=='contest'){
	$query=mysqli_query($link,"SELECT *,COUNT(*) as solved from contestsubmissions GROUP BY uname");
	while($row=$row=mysqli_fetch_array($query)) {
echo "<tr>
    <td>$i</td>
    <td>$row[uname]</td>
   <td>$row[solved]</td>
   </tr>"; 
   $i++;
	}
}
else{
$query=mysqli_query($link,"SELECT *,COUNT(*) as solved from submissions where Ptype='$Type' GROUP BY uname");
while($row=$row=mysqli_fetch_array($query)) {
echo "<tr>
<td>$i</td>
<td>$row[uname]</td>
<td>$row[solved]</td>
</tr>"; 
$i++;
	}
	
   }		
}
	echo'</table></div>';

?>
</body>
</html>
