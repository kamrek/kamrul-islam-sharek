<?php
session_start();

if(!isset($_SESSION['uname'])){
	echo "Access Denied!";
}
else{
	include("session.php");
	include("heading.php");	
}
?>
<?php

error_reporting(0);
if(isset($_POST['Pid']))
{
  $uname=$_SESSION['uname'];
  $Pid=$_POST['Pids'];
  $Pname=$_POST['Pnames'];
  $Uoutput=$_POST['result'];
  $nid=$_POST['Cid'];
  $result=$_POST['Decission'];
  $cpu=$_POST['sec'];
  $Type=$_POST['Type'];
  $Moutput=$_POST['Moutput'];
}
    $link=mysqli_connect("localhost","root","") or die("We couldn't connect !");
	mysqli_select_db($link,"RMSTUOJ");
	$query="SELECT output FROM easyarchieve WHERE Pid='$Pid'";
    $sq=mysqli_query($link,$query);
    $r3=mysqli_fetch_array($sq);

$ao=$r3['output'];

  if($result!="lt")
  {
   
    if($result=="e")
    {
      $result="Compilation Error";
    }
    else if(strcmp($uo,$ao)==0)
    {
      $result="Accepted";
    }
    else if($result=="rte")
    {
      $result="Runtime Error";
      
    }
    else
    {
      $result="Wrong Answer";
    }
  }
  else
  {
     $result="Time Limit Exceed";
  }
  $uname=$_SESSION['uname'];
  $Pid=$_POST['Pids'];
  $Pname=$_POST['Pnames'];
  $Uoutput=$_POST['result'];
  $cpu=$_POST['sec'];
  $Type=$_POST['Type'];
  $Moutput=$_POST['Moutput'];
	echo $uname ;
	echo $Pid;
	echo $Pname;
	echo $result;
	$sql="INSERT INTO submissions VALUES(null,'$uname','$Pid','$Pname','$result','$cpu') ";

   $show="SELECT * FROM submissions ORDER BY Id DESC limit $start,$per_page";

   $stq=mysqli_query($link,$sql);
   $sts=mysqli_query($link,$show);
	echo "<table>";
	while($row=mysqli_fetch_array($sts))
{

 echo "<tr>
	 </td><td><a href=\"profile.php?user=$row[uname]\">$row[uname]</a></td>
	 <td><a href=\"showcode.php?Pid=$row[Pid]&uname=$row[uname]\">$row[Pid]</a>
	 <td><a href=\"description.php?Pname=$row[Pname]\">$row[Pname]</a></td>
	 <td><div class=\"\">$row[Result]</div></td>
	 <td>$row[CPU]</td></tr>";

}
	
	echo "</table>";
	
?>