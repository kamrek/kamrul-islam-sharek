
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
	<link rel="stylesheet" href="css/footer.css"  type ="text/css">
</head>
<body>
	<div class="main_wrap footer_bg">
		<div class="wrap">
			<footer>
				<div id="footer">
				<p><b>Developed by</b></p>
					<p>Utpol Kanti Das,Kamrul Islam Sharek,Shadat hossain Hridoy&copy; 2019 RMSTU</p>
				</div>
			</footer>			
		</div>
	</div>
</body>
</html>