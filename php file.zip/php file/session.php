<?php 
        $time = time();
        $date = date('F d,Y');
        echo "<center>Today is: ".$date."</center>";
		echo"<center>"; include('time.php'); echo "</center>";
if(!isset($_SESSION['uname']) && isset($_COOKIE['My'])){
	$_SESSION['uname'] = $_COOKIE['RMSTUOnlineJudge'];
}
?>