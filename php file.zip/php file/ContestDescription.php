<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
	<link rel="stylesheet" href="css/ContestDescription.css"  type ="text/css">
</head>
<body>
<?php
session_start();

if(!isset($_SESSION['uname'])){
	echo "Access Denied!";
}
else{
	include("session.php");
	include("heading.php");	

	$id=$_REQUEST['id'];
	$link=mysqli_connect("localhost","root","") or die("We couldn't connect !");
    mysqli_select_db($link,"RMSTUOJ");
	$query=mysqli_query($link,"SELECT * from contestarchieve where Id=$id");
	$row = mysqli_fetch_assoc($query);
	$cid=$row['Cid'];
	$cn=$row['Cname'];
	$Pid=$row['Pid']; 
	$Pname=$row['Pname']; 
	$Pdes=$row['Pdes'];
	$ids=$row['Id'];  
	echo "<center>";
echo'
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
		<div id="wrapper">
	   <div id="container"><center>
	   <br /><h2><u>';echo"$cid&nbsp;&nbsp;$cn";echo'</u></h2><br /><br />
				  <form enctype="multipart/form-data" method="POST" action="ConSubmit.php">
				  <label for ="Pid">Problem Id :</label>&nbsp;&nbsp;
				  <input type="text" name="Pid" readonly value="';echo"$Pid";echo'" /><br><br>
				  <label for ="Pid">Problem Name :</label>&nbsp;&nbsp;
				  <input type="text" name="Pname" readonly value="';echo"$Pname";echo'" /><br><br>
				  <label for ="text"> Problem Description:</label><br><br>
				  <textarea name="Pdescription" readonly id="" cols="100" rows="30">';echo"$Pdes";echo'</textarea>
				  <input type="hidden" name="id" value="';echo"$ids";echo'"/><br> 
				  
				  </center>

				<center><br /><br /><input height="100" width="100" id="btn" type="submit" value="Submit" name="submit"></center> &nbsp;&nbsp;
                   </form>
	   </div>
	   </div>
	   </body>
</html>';
	echo"</center>";
}
?>
<div id="footera">

   <b>Developed by</b><br>
   <b>Utpol Kanti Das,Kamrul Islam Sharek, Shadat Hossain  Hridoy &copy; 2019 RMSTU. </b>

</div>
	
</body>
</html>


