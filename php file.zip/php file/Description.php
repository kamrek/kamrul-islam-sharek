<?php
session_start();

if(!isset($_SESSION['uname'])){
	echo "Access Denied!";
}
else{
	include("session.php");
	include("heading.php");	
}
?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
		<div id="wrapper">
	   <div id="container"><center>
	   <br /><h2><u><?php echo $_REQUEST["Pnames"];?></u></h2><br><br>
				  <form enctype="multipart/form-data" method="POST" action="Submit.php">
				  <label for ="Pid">Problem Id :</label>&nbsp;&nbsp;
				  <input type="text" name="Pid" readonly value="<?php echo $_REQUEST['Pids'];?>" /><br><br>
				  <label for ="text"> Problem Description:</label><br><br>
				  <textarea name="Pdescription" readonly id="" cols="30" rows="10"><?php echo $_REQUEST['pdes'];?></textarea>
				  <input type="hidden" name="Ptype" value="<?php echo $_REQUEST['Types'];?>"/><br> 
				  <input type="hidden" name="Status" value=""/><br>
				  <input type="Hidden" name="Submission" value=""/><br>
				  <input type="Hidden" name="Pname" value="<?php echo $_REQUEST["Pnames"];?>"/>';</center>

<?php
                 /*
				 $dir="problems/".$_REQUEST['Types']."/".$_REQUEST['Pids']."/images/";
					$open = opendir($dir);
					while(($file = readdir($open)) != FALSE){
						if($file !="."&& $file !=".."&&$file!="Thumbs.db"){
							echo "<center><img border='1' width='600' height='700' src='$dir/$file' alt='Problem Description' /><br/><br/></center>";
						}
					}
*/
	?>
				<center><input height="100" width="100" id="btn" type="submit" value="Submit" name="submit"></center> &nbsp;&nbsp;
				  <input type="hidden" name="Id" value="<?php echo $_REQUEST["Ids"];?>"/>
                   </form>
	   </div>
	   </div>
	   </body>
</html>




