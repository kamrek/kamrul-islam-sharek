<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
	<link rel="stylesheet" href="css/problems.css"  type ="text/css">
</head>
<body>
	

<?php
session_start();
$_SESSION['type'] = $_POST['type'];
if(!isset($_SESSION['uname'])){
	echo "Access Denied!";
}else{
	
	include("session.php");
	include("heading.php");	
	
	 $Type = $_SESSION['type'];
	echo "<br />";
	echo "<center><h1>Choose an Id to Solve</h1></center>";
global $link;
$link=mysqli_connect("localhost","root","") or die("We couldn't connect !");
mysqli_select_db($link,"RMSTUOJ");
/*
$per_page=2;

if($Type=='Easy'){
	$pages_query=mysqli_query($link,"SELECT Id from easyarchieve");
}else if($Type=='Beginner'){
	$pages_query=mysqli_query($link,"SELECT Id from beginnerarchieve");
}
else if($Type=='Medium'){
	$pages_query=mysqli_query($link,"SELECT Id from mediumarchieve");
}
else if($Type=='Hard'){
	$pages_query=mysqli_query($link,"SELECT Id from hardarchieve");
}

$pages = ceil(mysqli_num_rows($pages_query) / $per_page);

$page = (isset($_GET['page'])) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $per_page; 
 LIMIT $start,$per_page  */

if($Type=='Easy'){
	$query=mysqli_query($link,"SELECT * from easyarchieve");
}else if($Type=='Beginner'){
	$query=mysqli_query($link,"SELECT * from beginnerarchieve");
}
else if($Type=='Medium'){
	$query=mysqli_query($link,"SELECT * from mediumarchieve");
}
else if($Type=='Hard'){
	$query=mysqli_query($link,"SELECT * from hardarchieve");
}

echo "<center><div id='container'><table border=1>";
echo "<tr>
<td width=\"20%\" align=center bgcolor=\"FFFF00\">Problem Id</td>
<td width=\"40%\" align=center bgcolor=\"FFFF00\">Problem Name</td>
<td width=\"10%\" align=center bgcolor=\"FFFF00\">Status</td>
<td width=\"40%\" align=center bgcolor=\"FFFF00\">Submission</td>
</tr>";
while($row = mysqli_fetch_assoc($query)){
	$Pid=$row['Pid']; 
	$Pname=$row['Pname']; 
	$status=$row['Status']; 
	$submission=$row['Submission'];  
	$Pdes=$row['Pdes'];
	echo "<tr>
	    <td align=center>
		<a href=\"Description.php?Types=$Type&Pids=$Pid&Pnames=$Pname&Status=$status&Submission=$submission &pdes=$Pdes\">$Pid</a>
		</td>
		<td align=center>
		 $Pname
		</td>
		<td align=center>
		 $status
		</td>
		<td align=center>
		 $submission
		</td>
	</tr>";
}
echo "</table></center>";
/*
echo "<br> <center>";

$prev = $page -1;
$next = $page + 1;

if(!($page <= 1)){
	echo "<a href='problems.php?page=$prev'>Prev</a> ";
}

if($pages >= 1){
  for($x=1;$x<=$pages;$x++){
	  echo ($x == $page) ? '<b><a href="?page='.$x.'">'.$x. '</a></b>':'<a href="?page='.$x.'">'.$x.'</a> ';
  }
}

if(!($page>=$pages)){
	echo "<a href='problems.php?page=$next'>Next</a> ";
   } 

	echo "</center>"; */
	echo "</div>";
	mysqli_close($link);

}

?>
	 <div id="footera">

<b>Developed by</b><br>
<b>Utpol Kanti Das,Kamrul Islam Sharek, Shadat Hossain  Hridoy &copy; 2019 RMSTU. </b>

</div>
</body>
</html>