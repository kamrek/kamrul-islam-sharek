
<?php
session_start();

if(!isset($_SESSION['uname'])){
	echo "Access Denied!";
}
else{
	include("session.php");
	include("heading.php");	 
}
?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
			<title>RMSTU Online Judge</title>
		      <link rel="stylesheet" href="css/OnlineComliper.css"  type ="text/css">
</head>
<body>
<div id="whole">
<br />
<h1>Online Compiler</h1>
		<div id="contant">
				<form action="compile.php" method="post" id="form">
					Select Language of Interest:
						<select name="language" id="language">
							<option value="c">C</option>
							<option value="cpp">C++</option>
						</select>
					<br /><br />
					<strong>Enter Your code here:<br/></strong>
					<textarea name="code" rows=15 cols=100 onkeydown=insertTab(this,event) id="code"></textarea><br/>
					<span id="errorCode" class="error"></span><br/><br/>
					<strong>Sample Input please:<br/></strong>
					<textarea name="input" rows=7 cols=100 id="input"></textarea><br/><br/>
					<input type="submit" value="Submit" id="submit">
					<input type="reset" value="Reset"><br/><br/>

				</form>
				</div>
						
		</div>
   <div id="footera">

<b>Developed by</b><br>
<b>Utpol Kanti Das,Kamrul Islam Sharek, Shadat Hossain  Hridoy &copy; 2019 RMSTU. </b>

</div>
</body>
</html>