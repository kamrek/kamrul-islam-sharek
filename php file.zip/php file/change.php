<?php
session_start();

if(isset($_POST['submit'])){
   
		$mypic = $_FILES['newupload']['name'];
		$temp = $_FILES['newupload']['tmp_name'];
		$type = $_FILES['newupload']['type'];
		
		$Id = $_REQUEST['Id'];
		$newname = $_REQUEST['newname'];
		$newuname = $_REQUEST['newuname'];
		$newemail = $_REQUEST['newemail'];
		$newpassword = $_REQUEST['newpassword'];
		
		if($newname && $newuname && $newemail && $newpassword){
		
		if(preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/",$newemail)){
         
		 if(strlen($newpassword)>3){
		global $link;
		$link=mysqli_connect("localhost","root","") or die("We couldn't connect !");
		mysqli_select_db($link,"RMSTUOJ");
		mysqli_query($link,"UPDATE users SET name='$newname',uname='$newuname',email='$newemail',password='$newpassword'
		WHERE Id='$Id'");
		$md5 = md5($newpassword);
		mysqli_query($link,"UPDATE users SET password='$md5'
		WHERE Id='$Id'");
		if(($type=="image/jpeg") || ($type=="image/jpg") || ($type=="image/png") || ($type=="image/bmp")){
			$dir="profiles/".$_SESSION['uname']."/images";
			$files =0;
			$handle = opendir($dir);
			while(($file = readdir($handle)) != FALSE){
				if($file !="." && $file!=".." && $file!="Thumbs.db"){
					unlink($dir."/".$file);
					$files++;
					
				}
			}
				closedir($handle);
				sleep(1);
				rename("profiles/".$_SESSION['uname']."","profiles/$newuname");
				move_uploaded_file($temp,"profiles/$newuname/images/$mypic");
				echo "Your profile successfully updated.";
				mysqli_close($link);
				header("Refresh:2; url=logout.php");	
		}	
		else{
			echo "Please load a valid jpeg, jpg, png, bmp file!<br/>";
			}
		}
		else{
			echo "The password needs to be larger than 3 characters.";
		}
		}else{
			echo "Please enter a valid email.";
		}
				
		}else{
			echo "Please complete the form.";
		}
		
	}
	else{
	   echo "Access Not allowed!";
    }
?>