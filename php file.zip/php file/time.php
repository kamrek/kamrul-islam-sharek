
<script src="js/moment.min.js"></script>
<script> 
     function set(){

         document.getElementById('tx').innerHTML="<b>Time : "+ moment().format('h:mm:ss a') +"</b>";
         var t=setTimeout(set,1000);
      }

</script>


<body onload="set()">

<script> 
     function set(){

         //document.getElementById('tx').innerHTML= hour + ":" + min +":" + sec;
         document.getElementById('tx').innerHTML="<b><center>Server Time : "+ moment().format('h:mm:ss a') +"</center></b>";
         var t=setTimeout(set,1000);
      }
 
</script>

<div id="tx"></div>
</body>