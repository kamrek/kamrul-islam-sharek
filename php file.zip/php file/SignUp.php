
<!DOCTYPE html>

<html>
    <head>
	 
           <title>Sign Up</title>
		   <link rel="stylesheet" href="css/login.css"  type ="text/css">
	        <meta charset="utf-8">
        
    </head>
	 
		<body>
			   <div id="wrapper">
		        <div id="navbar">
					 <ul>
			           <li><a href="#">Compiler</a></li>
			           <li><a href="#">Problem Archive </a></li>
			           <li><a href="#">Contests </a></li>
                       <li><a href="#">Debug</a></li>
			           <li><a href="Login.php">LogIn</a></li>
					   <li><a href="#">SignUp</a></li>
					</ul>
			       </div>
  
				   <center>	
			      <div id="container">
				  <h2 style =""><u>Sign Up</u></h2><br><br>
				  <form enctype="multipart/form-data" method="POST" action="SignUpInsert.php">
				  <label for ="name">Name</label><br>
				  <input type="text" name="name" placeholder="Enter Your Name"><br>
				  <label for ="text"> User Name</label><br>
				  <input type="uname" name="uname" placeholder="Enter username"><br>
				  <label for ="email">Email</label><br>
				  <input type="email" name="email" placeholder="Enter Email"><br>
				  <label for ="password">Password</label><br>
				  <input type="password" name="password" placeholder="Enter password"><br>
				  <label for ="Confirmpassword">Confirm Password</label><br>
				  <input type="password" name="Confirmpassword" placeholder="Enter password"><br>
				  <label for ="Image">Choose your Picture</label><br>
				 <input type="file" name="fileToUpload" id="fileToUpload"><br/><br/>

				  <div  id="btn"><input type="submit" value="Submit" name="submit"> &nbsp;&nbsp; 
				  <input type="reset" value="Reset"/></button></div>
                   </form>
	   
</div>
</center>

					<div id="footer">
					Developed By <br />
					Utpol Kanti Das,Kamrul Islam Sharek, ShadatHossain  Hridoy &copy; 2019 RMSTU.
					</div>
		    
			</div>
       </body>
</html>