<?php
session_start();
  if(isset($_SESSION['uname'])||isset($_COOKIE['RMSTUOnlineJudge'])){
	    $time = time();
        $date = date('F d,Y');
        echo "<center>Today is: ".$date."<br/></center>";
		include('time.php');
		include('RMSTUOJ.php');
  }else{
	  echo "Access Denied!";
	  header('Refresh:2; url=Login.php');
  }
?>