-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 06, 2019 at 09:27 PM
-- Server version: 10.1.22-MariaDB
-- PHP Version: 7.0.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rmstuoj`
--

-- --------------------------------------------------------

--
-- Table structure for table `easyarchieve`
--

CREATE TABLE `easyarchieve` (
  `Id` int(15) NOT NULL,
  `Pid` varchar(20) NOT NULL,
  `Pname` varchar(50) NOT NULL,
  `Pdes` text NOT NULL,
  `Status` varchar(15) NOT NULL DEFAULT 'Unsolved',
  `Submission` varchar(15) NOT NULL DEFAULT 'No Submission',
  `Input` varchar(1024) NOT NULL,
  `Output` varchar(1024) NOT NULL,
  `Timelim` varchar(5) NOT NULL DEFAULT '3.00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `easyarchieve`
--

INSERT INTO `easyarchieve` (`Id`, `Pid`, `Pname`, `Pdes`, `Status`, `Submission`, `Input`, `Output`, `Timelim`) VALUES
(1, 'Pid-001', 'Extremely Basic', 'Read 2 variables, named A and B and make the sum of these two variables, assigning its result to the variable X. Print X as shown below. Print endline after the result otherwise you will get “Presentation Error”.\r\n\r\nInput\r\nThe input file will contain 2 integer numbers.\r\n\r\nOutput\r\nPrint the letter X (uppercase) with a blank space before and after the equal signal followed by the value of X, according to the following example.\r\n\r\nObs.: don\'t forget the endline after all.\r\n\r\nSamples Input	Samples Output\r\n10\r\n9\r\n\r\nX = 19\r\n\r\n-10\r\n4\r\n\r\nX = -6\r\n\r\n15\r\n-7\r\n\r\nX = 8', 'Unsolved', 'No Submission', '10 9\r\n-10 4\r\n15 -7', 'X = 19\r\nX = -6\r\nX = 8\r\n', '1.00'),
(2, 'Pid-002', 'Area of a Circle', 'The formula to calculate the area of a circumference is defined as A = ? . R2. Considering to this problem that ? = 3.14159:\r\n\r\nCalculate the area using the formula given in the problem description.\r\n\r\nInput\r\nThe input contains a value of floating point (double precision), that is the variable R.\r\n\r\nOutput\r\nPresent the message \"A=\" followed by the value of the variable, as in the example bellow, with four places after the decimal point. Use all double precision variables. Like all the problems, don\'t forget to print the end of line after the result, otherwise you will receive \"Presentation Error\".\r\n\r\nInput Samples	Output Samples\r\n2.00\r\n\r\nA=12.5664\r\n\r\n100.64\r\n\r\nA=31819.3103\r\n\r\n150.00\r\n\r\nA=70685.7750', 'Unsolved', 'No Submission', '2.00\r\n100.64\r\n150.00', 'A=12.5664\r\nA=31819.3103\r\nA=70685.7750\r\n', '1.00'),
(3, 'Pid-003', 'Simple Sum', 'Read two integer values, in this case, the variables A and B. After this, calculate the sum between them and assign it to the variable SOMA. Write the value of this variable.\r\n\r\nInput\r\nThe input file contains 2 integer numbers.\r\n\r\nOutput\r\nPrint the variable SOMA with all the capital letters, with a blank space before and after the equal signal followed by the corresponding value to the sum of A and B. Like all the problems, don\'t forget to print the end of line, otherwise you will receive \"Presentation Error\"\r\n\r\nInput Samples	Output Samples\r\n30\r\n10\r\n\r\nSOMA = 40\r\n\r\n-30\r\n10\r\n\r\nSOMA = -20\r\n\r\n0\r\n0\r\n\r\nSOMA = 0', 'Unsolved', 'No Submission', '30 10\r\n-30 10\r\n0 0', 'SOMA = 40\r\nSOMA = -20\r\nSOMA = 0\r\n', '1.00'),
(4, 'Pid-004', 'Simple Product', 'Read two integer values. After this, calculate the product between them and store the result in a variable named PROD. Print the result like the example below. Do not forget to print the end of line after the result, otherwise you will receive “Presentation Error”.\r\n\r\nInput\r\nThe input file contains 2 integer numbers.\r\n\r\nOutput\r\nPrint PROD according to the following example, with a blank space before and after the equal signal.\r\n\r\nInput Samples	Output Samples\r\n3\r\n9\r\n\r\nPROD = 27\r\n\r\n-30\r\n10\r\n\r\nPROD = -300\r\n\r\n0\r\n9\r\n\r\nPROD = 0', 'Unsolved', 'No Submission', '3 9\r\n-30 10\r\n0 9', 'PROD = 27\r\nPROD = -300\r\nPROD = 0\r\n', '1.00'),
(5, 'Pid-005', 'Average 1', 'Read two floating points\' values of double precision A and B, corresponding to two student\'s grades. After this, calculate the student\'s average, considering that grade A has weight 3.5 and B has weight 7.5. Each grade can be from zero to ten, always with one digit after the decimal point. Don’t forget to print the end of line after the result, otherwise you will receive “Presentation Error”. Don’t forget the space before and after the equal sign.\r\n\r\nInput\r\nThe input file contains 2 floating points\' values with one digit after the decimal point.\r\n\r\nOutput\r\nPrint MEDIA(average in Portuguese) according to the following example, with 5 digits after the decimal point and with a blank space before and after the equal signal.\r\n\r\nInput Samples	Output Samples\r\n5.0\r\n7.1\r\n\r\nMEDIA = 6.43182\r\n\r\n0.0\r\n7.1\r\n\r\nMEDIA = 4.84091\r\n\r\n10.0\r\n10.0\r\n\r\nMEDIA = 10.00000', 'Unsolved', 'No Submission', '5.0 7.1\r\n0.0 7.1\r\n10.0 10.0', 'MEDIA = 6.43182\r\nMEDIA = 4.84091\r\nMEDIA = 10.00000\r\n', '1.00'),
(6, 'Pid-006', 'Average 2', 'Read three values (variables A, B and C), which are the three student\'s grades. Then, calculate the average, considering that grade A has weight 2, grade B has weight 3 and the grade C has weight 5. Consider that each grade can go from 0 to 10.0, always with one decimal place.\r\n\r\nInput\r\nThe input file contains 3 values of floating points with one digit after the decimal point.\r\n\r\nOutput\r\nPrint MEDIA(average in Portuguese) according to the following example, with a blank space before and after the equal signal.\r\n\r\nInput Samples	Output Samples\r\n5.0\r\n6.0\r\n7.0\r\n\r\nMEDIA = 6.3\r\n\r\n5.0\r\n10.0\r\n10.0\r\n\r\nMEDIA = 9.0\r\n\r\n10.0\r\n10.0\r\n5.0\r\n\r\nMEDIA = 7.5', 'Unsolved', 'No Submission', '5.0 6.0 7.0\r\n5.0 10.0 10.0\r\n10.0 10.0 5.0', 'MEDIA = 6.3\r\nMEDIA = 9.0\r\nMEDIA = 7.5\r\n', '1.00'),
(7, 'Pid-007', 'Difference', 'Read four integer values named A, B, C and D. Calculate and print the difference of product A and B by the product of C and D (A * B - C * D).\r\n\r\nInput\r\nThe input file contains 4 integer values.\r\n\r\nOutput\r\nPrint DIFERENCA (DIFFERENCE in Portuguese) with all the capital letters, according to the following example, with a blank space before and after the equal signal.\r\n\r\nInput Samples	Output Samples\r\n5\r\n6\r\n7\r\n8\r\n\r\nDIFERENCA = -26\r\n\r\n0\r\n0\r\n7\r\n8\r\n\r\nDIFERENCA = -56\r\n\r\n5\r\n6\r\n-7\r\n8\r\n\r\nDIFERENCA = 86', 'Unsolved', 'No Submission', '5 6 7 8\r\n0 0 7 8\r\n5 6 -7 8', 'DIFERENCA = -26\r\nDIFERENCA = -56\r\nDIFERENCA = 86\r\n', '1.00'),
(8, 'Pid-008', 'Salary', 'Write a program that reads an employee\'s number, his/her worked hours number in a month and the amount he received per hour. Print the employee\'s number and salary that he/she will receive at end of the month, with two decimal places.\r\n\r\nDon’t forget to print the line\'s end after the result, otherwise you will receive “Presentation Error”.\r\nDon’t forget the space before and after the equal signal and after the U$.\r\nInput\r\nThe input file contains 2 integer numbers and 1 value of floating point, representing the number, worked hours amount and the amount the employee receives per worked hour.\r\n\r\nOutput\r\nPrint the number and the employee\'s salary, according to the given example, with a blank space before and after the equal signal.\r\n\r\nInput Samples	Output Samples\r\n25\r\n100\r\n5.50\r\n\r\nNUMBER = 25\r\nSALARY = U$ 550.00\r\n\r\n1\r\n200\r\n20.50\r\n\r\nNUMBER = 1\r\nSALARY = U$ 4100.00\r\n\r\n6\r\n145\r\n15.55\r\n\r\nNUMBER = 6\r\nSALARY = U$ 2254.75', 'Unsolved', 'No Submission', '25 100 5.50\r\n1 200 20.50\r\n6 145 15.55', 'NUMBER = 25\r\nSALARY = U$ 550.00\r\nNUMBER = 1\r\nSALARY = U$ 4100.00\r\nNUMBER = 6\r\nSALARY = U$ 2254.75\r\n', '1.00'),
(9, 'Pid-009', 'Fuel Spent', 'Little John wants to calculate and show the amount of spent fuel liters on a trip, using a car that does 12 Km/L. For this, he would like you to help him through a simple program. To perform the calculation, you have to read spent time (in hours) and the same average speed (km/h). In this way, you can get distance and then, calculate how many liters would be needed. Show the value with three decimal places after the point.\r\n\r\nInput\r\nThe input file contains two integers. The first one is the spent time in the trip (in hours). The second one is the average speed during the trip (in Km/h).\r\n\r\nOutput\r\nPrint how many liters would be needed to do this trip, with three digits after the decimal point.\r\n\r\nInput Sample	Output Sample\r\n10\r\n85\r\n\r\n70.833\r\n\r\n2\r\n92\r\n\r\n15.333\r\n\r\n22\r\n67\r\n\r\n122.833', 'Unsolved', 'No Submission', '10 85\r\n2 92\r\n22 67', '70.833\r\n15.333\r\n122.833\r\n', '1.00'),
(10, 'Pid-010', 'Banknotes', 'In this problem you have to read an integer value and calculate the smallest possible number of banknotes in which the value may be decomposed. The possible banknotes are 100, 50, 20, 10, 5, 2 e 1. Print the read value and the list of banknotes.\r\n\r\nInput\r\nThe input file contains an integer value N (0 < N < 1000000).\r\n\r\nOutput\r\nPrint the read number and the minimum quantity of each necessary banknotes in Portuguese language, as the given example. Do not forget to print the end of line after each line, otherwise you will receive “Presentation Error”.\r\n\r\nInput Sample	Output Sample\r\n576\r\n\r\n576\r\n5 nota(s) de R$ 100,00\r\n1 nota(s) de R$ 50,00\r\n1 nota(s) de R$ 20,00\r\n0 nota(s) de R$ 10,00\r\n1 nota(s) de R$ 5,00\r\n0 nota(s) de R$ 2,00\r\n1 nota(s) de R$ 1,00\r\n\r\n11257\r\n\r\n11257\r\n112 nota(s) de R$ 100,00\r\n1 nota(s) de R$ 50,00\r\n0 nota(s) de R$ 20,00\r\n0 nota(s) de R$ 10,00\r\n1 nota(s) de R$ 5,00\r\n1 nota(s) de R$ 2,00\r\n0 nota(s) de R$ 1,00\r\n\r\n503\r\n\r\n503\r\n5 nota(s) de R$ 100,00\r\n0 nota(s) de R$ 50,00\r\n0 nota(s) de R$ 20,00\r\n0 nota(s) de R$ 10,00\r\n0 nota(s) de R$ 5,00\r\n1 nota(s) de R$ 2,00\r\n1 nota(s) de R$ 1,00', 'Unsolved', 'No Submission', '576\r\n11257\r\n503', '576\r\n5 nota(s) de R$ 100,00\r\n1 nota(s) de R$ 50,00\r\n1 nota(s) de R$ 20,00\r\n0 nota(s) de R$ 10,00\r\n1 nota(s) de R$ 5,00\r\n0 nota(s) de R$ 2,00\r\n1 nota(s) de R$ 1,00\r\n11257\r\n112 nota(s) de R$ 100,00\r\n1 nota(s) de R$ 50,00\r\n0 nota(s) de R$ 20,00\r\n0 nota(s) de R$ 10,00\r\n1 nota(s) de R$ 5,00\r\n1 nota(s) de R$ 2,00\r\n0 nota(s) de R$ 1,00\r\n503\r\n5 nota(s) de R$ 100,00\r\n0 nota(s) de R$ 50,00\r\n0 nota(s) de R$ 20,00\r\n0 nota(s) de R$ 10,00\r\n0 nota(s) de R$ 5,00\r\n1 nota(s) de R$ 2,00\r\n1 nota(s) de R$ 1,00\r\n', '1.00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `easyarchieve`
--
ALTER TABLE `easyarchieve`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `easyarchieve`
--
ALTER TABLE `easyarchieve`
  MODIFY `Id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
